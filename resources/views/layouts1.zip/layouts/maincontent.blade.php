<div class="container  content-center" style="background-color: rgb(227, 245, 230);">

    <div class="col-lg-12 col-6">

        <a href="journals.uofg.edu.sd/">
            <img class="img-responsive" src="images\ojs3.png" alt=""></a>

        <a href="elearn.uofg.edu.sd/">
            <img class="img-responsive" src="images\moodle.png" alt=""></a>

        <a href="repo.uofg.edu.sd/">
            <img class="img-responsive" src="images\repo.png" alt=""></a>

   <a href="elib.uofg.edu.sd/">
        <img class="img-responsive" src="images\koha.png" alt=""></a>
    </div>

</div>

<div class="container  content-center">

    <div class="col-lg-12 col-6">
        <section class="section-content py-5">
            <h2 style="text-align: center;  color: rgb(37, 77, 51)">Number of Students</h2>

            <br>

            <div class="row">
              <div class="column">
                <div class="card">
                  <p><i class="fa fa-user"></i></p>
                  <h3>28000+</h3>
                  <p>Undergraduates</p>
                </div>
              </div>

              <div class="column">
                <div class="card">
                  <p><i class="fa fa-user"></i></p>
                  <h3>4000+</h3>
                  <p>Postgraduates</p>
                </div>
              </div>

              <div class="column">
                <div class="card">
                  <p><i class="fa fa-user"></i></p>
                  <h3>4800+</h3>
                  <p>Technical Diploma</p>
                </div>
              </div>


            </div>

          </section>


    </div>

</div>
</div>
