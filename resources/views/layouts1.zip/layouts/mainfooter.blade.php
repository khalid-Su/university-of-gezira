
<div class="container content-center text-white font-medium" style="background-color: rgb(4, 37, 19);">

<div class="row">

    <div class="col-lg-3 col-md-3 col-sm-2">
        <h6><i class=" glyphicon glyphicon-home"></i>About UofG</h6>
        <p>The University of Gezira was established in the city of Wad Medani, the capital of the Gezira state in accordance with a Republican Decree issued on the 19th of November 1975.<a class="box-icon-more font-lato weight-300" href="https://web.archive.org/web/20230331195539/http://en.uofg.edu.sd/about.aspx?page=1">More</a> .</p>

    </div>

    <div class="col-lg-3 col-md-3 col-sm-2">
      <h6><i class="glyphicon glyphicon-education" style="text-align: center"></i>Admission</h6>
        <ul class="list-unstyled">
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>Admission to Postgraduate Diploma Program</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>Admission to the Master's Program</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>Admission to the Doctoral Program</a></li>
              </ul>
    </div>
 <div class="col-lg-3 col-md-3 col-sm-2">
        <h6><i class="glyphicon glyphicon-book"></i>Information About</h6>
        <ul class="list-unstyled">
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>University Academic System</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>Academic Supervision University</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-triangle-left"></i>Registration procedures for new students</a></li>

        </ul>
    </div>

    <div class="col-lg-3 col-md-3 col-sm-2">

        <ul class="list-unstyled">

            <li><h6><i class="glyphicon glyphicon-map-marker"></i>Contact us</h6></li>

            <li><i class="icon-envelope"></i><b>Address</b> Wadmedani, Sudan</li>
        <li><i class="icon-envelope"></i><b>E-mail</b> info@uofg.edu.sd</li>
            <li><i class="glyphicon glyphicon-earphone"></i><b>Phone</b>(00249)5118 43174</li>
    <li><i class="glyphicon glyphicon-phone-alt"></i><b>Phone</b>(00249)5118 40466</li>
     <li><i class="icon-envelope"></i><b>Fax</b>+249 183487591</li>

     <!-- social media -->


        <a href="https://www.facebook.com/uofg.edu.sd" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-youtube"></a>
        <a href="#" class="fa fa-instagram"></a>



    </ul>
    </div>

</div>
</div>




