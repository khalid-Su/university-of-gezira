
<div class="navbar">
    <a href="#home">Home</a>
    <a href="#news">News</a>
    <div class="dropdown">
      <button class="dropbtn">Faculties
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <div class="header">
          <h2>Sectors</h2>
        </div>
        <div class="row">
          <div class="column">
            <h3>Health Sector</h3>
            <a href="#">Faculty of Medcine</a>
            <a href="#">Faculty Dentistry</a>
            <a href="#">Faculty of Applied Medical Sciences</a>
            <a href="#">Faculty of Medical Labrotaries Sciences</a>
            <a href="#">Faculty of Pharmacy</a>
          </div>
          <div class="column">
            <h3>Engineering and Applied Sciences</h3>
            <a href="#">Faculty of Mathematical and Computer Sciences</a>
            <a href="#">Faculty of Science</a>
            <a href="#">Faculty of Engineering and Technology</a>
             <a href="#">Faculty of Industries Engineering and Technology</a>
          </div>
          <div class="column">
            <h3>Humanities</h3>
            <a href="#">Faculty of Education -Hantoup</a>
            <a href="#">Faculty of Education -Hasahesa</a>
            <a href="#">Faculty of Arts and Humanties Sciences</a>
          </div>
           <div class="column">
            <h3>Social Sciences</h3>
            <a href="#">Faculty of Economics and Rural Devlopment</a>
            <a href="#">Faculty of Comercial Studies</a>
            <a href="#">Faculty of Developmental Studies</a>
               <a href="#">Faculty of Law</a>
          </div>
             <div class="column">
            <h3>Social Sciences</h3>
            <a href="#">Faculty of Communinity</a>

          </div>
        </div>
      </div>
    </div>
     <div class="dropdown">
      <button class="dropbtn">Inistitutes
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <div class="header">

        </div>
        <div class="row">
          <div class="column">

            <a href="#">Faculty of Medcine</a>
            <a href="#">Faculty Dentistry</a>
            <a href="#">Faculty of Applied Medical Sciences</a>
            <a href="#">Faculty of Medical Labrotaries Sciences</a>
            <a href="#">Faculty of Pharmacy</a>
          </div>
          <div class="column">

            <a href="#">Faculty of Mathematical and Computer Sciences</a>
            <a href="#">Faculty of Science</a>
            <a href="#">Faculty of Engineering and Technology</a>
             <a href="#">Faculty of Industries Engineering and Technology</a>
          </div>

        </div>
      </div>
    </div>
  </div>

