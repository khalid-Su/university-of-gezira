<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<div style=" text-align: center; padding: 3px; background-color: rgb(69, 70, 69); color:white;">
<div class=" col-lg-8 col-sm-4 container">
Copyright<i class="material-icons">copyright</i> 2024 - All Rights Reserved - University Of Gezira   Designed by Computer and Information Technology Center

    </div>
</div>
