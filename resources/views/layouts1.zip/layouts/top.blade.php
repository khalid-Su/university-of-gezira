<header class="section-header py-4">
    <div class="container">
        <div class="row g-3">
        <div class="col-lg-4 col-6">
        <img src="images/newlogo.png">
        </div>
        <div class="col-lg-4 col-6">

            <nav class="navbar navbar-expand-lg" >
                <div class="container">

                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="navbar-nav">

                        <ul class="navbar-nav ms-auto">


                            <li class="nav-item dropdown">
                                <a class="nav-link  dropdown-toggle href="#" data-bs-toggle="dropdown"> E-Services</a>
                                <ul class="dropdown-menu" style="background-color: rgba(2, 37, 20, 0.808); color:rgb(245, 25, 80)">
                                  <li><a  href="https://webmail.uofg.edu.sd"> E-mail</a></li>
                                  <li><a  href="https://news.uofg.edu.sd"> News </a></li>
                                  <li><a  href="#"> E-library </a></li>
                                  <li><a  href="#"> Journals </a></li>
                                  <li><a  href="#"> E-Learning </a></li>
                                  <li><a  href="#"> D-Space </a></li>
                                  <li><a  href="#"> Conferences </a></li>
                                </ul>
                            </li>


                        </ul>

                    </ul>
                </div>
                </div>
                </nav>

        </div>
        <div class="col-lg-4 col-3">

            <nav class="navbar navbar-expand-lg" >
                <div class="container-fluid">

                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="navbar-nav">

                        <ul class="navbar-nav ms-auto">

                            <li class="nav-item dropdown">
                                <a class="nav-link  dropdown-toggle text-black href="#" data-bs-toggle="dropdown"><img class="flag-lang" src="images/us.png" width="16" height="11" alt="lang"> English</a>
                                <ul class="dropdown-menu" style="background-color:white; color: rgba(2, 37, 20, 0.808)">
                                  <li> <img class="flag-lang" src="images/us.png" width="16" height="11" alt="lang"> <a style="background-color:white; color: rgba(2, 37, 20, 0.808) href="#"> English</a></li>
                                  <li><img class="flag-lang" src="images/sd.png" width="16" height="11" alt="lang"><a style="background-color:white; color: rgba(2, 37, 20, 0.808)" href="#"> Arabic </a></li>
                                </ul>
                            </li>

                        </ul>

                    </ul>
                </div>
                </div>
                </nav>

        </div>
</div>

        </div>
    </div>
</header> <!-- section-header.// -->
