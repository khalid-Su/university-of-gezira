<div class="container" >

<!-- ============= COMPONENT ============== -->
<nav class="navbar navbar-expand-lg bg-gray-800" >
<div class="container-fluid">

<div class="collapse navbar-collapse" id="main_nav">
    <ul class="navbar-nav">

        <ul class="navbar-nav ms-auto">
            <li class="nav-item dropdown">
                <a class="nav-link  dropdown-toggle " href="#" data-bs-toggle="dropdown"> English </a>
                <ul class="dropdown-menu dropdown-menu-end bg-gray-800">
                  <li><a class="dropdown-item bg-gray-800 text-left" href="#"> English</a></li>
                  <li><a class="dropdown-item bg-gray-800 text-left" href="#"> Arabis </a></li>
                </ul>
            </li>
        </ul>

    </ul>
</div>
</div>
</nav>
</div>
