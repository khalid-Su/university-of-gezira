<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel" class="container">

    <!-- Indicators/dots -->
    <div class="carousel-indicators" style="container">
      <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
      <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
      <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
      <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
    </div>

    <!-- The slideshow/carousel -->
    <div class="carousel-inner container">
      <div class="carousel-item active" >
        <img src="/images/mainslide/imam1.jpg" alt="Islamic studies and Islamization of knewlodege" class="d-block" style="width:100%">
        <div class="carousel-caption">

          <p></p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="/images/mainslide/meusum1.jpg" alt="Faculty of Medicine Museum" class="d-block" style="width:100%">
        <div class="carousel-caption">
          <h3></h3>
          <p></p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="/images/mainslide/Textileslab.jpg" alt="textile lab" class="d-block" style="width:100%">
        <div class="carousel-caption">
          <h3></h3>
          <p></p>
        </div>
      </div>

      <div class="carousel-item">
        <img src="/images/mainslide/ChemistryLab.jpg" alt="Chemistry lab" class="d-block" style="width:100%">
        <div class="carousel-caption">
          <h3></h3>
          <p></p>
        </div>
      </div>
    </div>

    <!-- Left and right controls/icons -->
    <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
