<div class="navbar">
    <div class="navbar-inner">
        <div class="container">
            <div class="nav-collapse collapse">
                <ul class="nav">
                    <li class="dropdown mega-menu-4 transition">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">$category <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li class="one-column">
                                <ul>
                                    <li class="nav-title">$subCategory 1</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                                <ul>
                                    <li class="nav-title">$subCategory 1</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                            </li>
                            <li class="one-column">
                                <ul>
                                    <li class="nav-title">$subCategory 2</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                                <ul>
                                    <li class="nav-title">$subCategory 2</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                            </li>
                            <li class="one-column">
                                <ul>
                                    <li class="nav-title">$subCategory 3</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                                <ul>
                                    <li class="nav-title">$subCategory 3</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                            </li>
                            <li class="one-column">
                                <ul>
                                    <li class="nav-title">$subCategory 4</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                                <ul>
                                    <li class="nav-title">$subCategory 4</li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                    <li><a href="#">$course</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
