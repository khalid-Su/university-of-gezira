<!-- Include Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<!-- Footer Section -->
<div class="text-center py-3" style="background-color: rgb(69, 70, 69); color: white; ">
    <div class=" col-lg-11 col-md-12" >
     
            <p class="mb-0">
                Copyright &copy; 2024 - All Rights Reserved - University Of Gezira
                <span class="material-icons"></span>
                    | Designed by Computer and Information Technology Center
            </p>
      
    </div>
</div>
